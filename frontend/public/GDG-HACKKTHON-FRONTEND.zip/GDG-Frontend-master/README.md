This is repo for Frontend code for GDG VIT AP Website

STYLE GUIDE LINK : https://www.notion.so/GDG-Web-and-App-Team-Style-Guide-1947103aaeb680dea680e296373330ab

CODE REVIEW GUIDELINES / BEST PRACTICES : https://www.notion.so/Code-Review-Guidelines-Best-Practices-1947103aaeb6801686aac10d380db8ed

If you are making App bar and Footer while creating your page make sure assign yourself to the issue for that as well
similarly if someone has already self assigned themselves to the issue of App bar and Footer no need to add app bar / footer to the page, add them later after components of the same are created

The Tech Stack being used on this repo is 

React.js (Javascipt) with Tailwind CSS

How to get started working on the repo

1. Fork the repo 
2. git clone the repo you have forked 
```
  git clone "YOUR_REPO_LINK.git"
```

3. run npm install

4. add backend link provided (if you do not have it DM Web and App team lead on whatsapp) in the .env file (refer to .env.example

The Set up is done!
                                                                                                            
