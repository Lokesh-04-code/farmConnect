import './App.css'

function App() {
  return (
    <>
  <h1 class="text-4xl font-bold underline">
    Nothing here yet!
  </h1>
    </>
  )
}

export default App
